# mupdf

Simple script to build the [MuPDF](http://mupdf.com/) libraries that are needed for one of my Go projects.
