# C bindings for Skia

These have been tailored to the needs of my specific projects and may not be suitable for anyone else.

## Skia version

The Skia version with which these bindings have been tested is from _Thu Aug 18 16:12:52 PDT 2022_
* https://github.com/google/skia/tree/chrome/m105
* https://chromium.googlesource.com/chromium/tools/depot_tools.git/+/1cf1fb5d214aab7afec77d2fd646addea34e52ff

See the file skia/skia/RELEASE_NOTES.txt for changes made to skia.
